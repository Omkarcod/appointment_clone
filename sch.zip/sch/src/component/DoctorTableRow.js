export const DoctorTableRow = [
    {
      id: 1,
      time:"10:30 AM",
      patientName: "Milka",
      doctorName: "Amelia Edwards",
      symptoms: "Swelling or bruisiling..",
    },
    {
      id: 2,
      time:"01:00 PM",
      patientName: "Laura",
      doctorName: "Nembo Lukeni",
      symptoms: "Sweating,Chills a...",
    },
    {
      id: 3,
      time:"04:00 PM",
      patientName: "Adams",
      doctorName: "Yara Barros",
      symptoms: "Frequent squintin...",
    },
    {
      id: 4,
      time:"07:00 PM",
      patientName: "Milka",
      doctorName: "Alexa Richardson",
      symptoms: "Feeling of lighting...",
    },
  ];