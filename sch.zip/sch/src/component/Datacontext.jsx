import { createContext } from "react";

const DataContext=createContext();
export default DataContext;