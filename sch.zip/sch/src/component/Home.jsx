import React from 'react'
import Topnav from './Topnav'
import { BrowserRouter } from 'react-router-dom'

const Home = () => {
  return (
    <BrowserRouter>
    <Topnav/>
    </BrowserRouter>
    
  )
}

export default Home