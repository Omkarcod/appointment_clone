import React from 'react'

const Cals = () => {
  return (
    <div>Cals</div>
  )
}

export default Cals